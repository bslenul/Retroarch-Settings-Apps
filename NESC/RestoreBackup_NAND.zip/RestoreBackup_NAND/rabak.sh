#!/bin/sh

if [ -f /etc/ra_backup/retroarch.cfg ]
then
	rm -rf /etc/libretro/.config/retroarch/config
	cp /etc/ra_backup/retroarch.cfg /etc/libretro
	cp /etc/ra_backup/retroarch-core-options.cfg /etc/libretro
	cp -r /etc/ra_backup/config /etc/libretro/.config/retroarch
fi