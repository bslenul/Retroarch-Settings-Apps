#!/bin/sh

cp /etc/ra_backup/retroarch.cfg /etc/libretro
cp /etc/ra_backup/retroarch-core-options.cfg /etc/libretro
cp -r /etc/ra_backup/config /etc/libretro/.config/retroarch