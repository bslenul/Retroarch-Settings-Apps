#!/bin/sh

rm -r /etc/ra_backup