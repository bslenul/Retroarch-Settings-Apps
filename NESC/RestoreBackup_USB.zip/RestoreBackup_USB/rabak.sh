#!/bin/sh

cp /media/data/ra_backup/retroarch.cfg /etc/libretro
cp /media/data/ra_backup/retroarch-core-options.cfg /etc/libretro
cp -r /media/data/ra_backup/config /etc/libretro/.config/retroarch