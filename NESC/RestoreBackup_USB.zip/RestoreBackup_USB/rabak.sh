#!/bin/sh

if [ -f /media/data/ra_backup/retroarch.cfg ]
then
	rm -rf /etc/libretro/.config/retroarch/config
	cp /media/data/ra_backup/retroarch.cfg /etc/libretro
	cp /media/data/ra_backup/retroarch-core-options.cfg /etc/libretro
	cp -r /media/data/ra_backup/config /etc/libretro/.config/retroarch
fi