#!/bin/sh

rm -rf /etc/ra_backup
rm -rf /media/data/ra_backup
