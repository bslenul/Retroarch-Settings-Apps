#!/bin/sh

if [ -d /etc/ra_backup ]
then
	rm -rf /etc/ra_backup/*
else
	mkdir -m 777 /etc/ra_backup
fi
cp /etc/libretro/retroarch.cfg /etc/ra_backup
cp /etc/libretro/retroarch-core-options.cfg /etc/ra_backup
cp -r /etc/libretro/.config/retroarch/config /etc/ra_backup