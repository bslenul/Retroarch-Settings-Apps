#!/bin/sh

if [ -d /media/data/ra_backup ]
then
	rm -rf /media/data/ra_backup/*
else
	mkdir -pm 777 /media/data/ra_backup
fi
cp /etc/libretro/retroarch.cfg /media/data/ra_backup
cp /etc/libretro/retroarch-core-options.cfg /media/data/ra_backup
cp -r /etc/libretro/.config/retroarch/config /media/data/ra_backup