#!/bin/sh

cp /usr/share/games/CLV-P-RASET/retroarch.cfg /etc/libretro/
cp /usr/share/games/CLV-P-RASET/retroarch-core-options.cfg /etc/libretro/
