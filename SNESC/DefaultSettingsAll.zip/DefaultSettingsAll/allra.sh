#!/bin/sh

cp /usr/share/games/CLV-P-ALLRA/retroarch.cfg /etc/libretro/
cp /usr/share/games/CLV-P-ALLRA/retroarch-core-options.cfg /etc/libretro/
rm -r /etc/libretro/.config/retroarch/config/*
mkdir -m 777 /etc/libretro/.config/retroarch/config/remaps
