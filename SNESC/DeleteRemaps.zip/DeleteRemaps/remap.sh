#!/bin/sh

rm -r /etc/libretro/.config/retroarch/config/remaps/*
